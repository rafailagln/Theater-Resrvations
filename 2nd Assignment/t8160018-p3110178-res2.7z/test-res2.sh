#!/bin/bash
gcc -Wall t8160018-p3110178-res2.c -pthread
./a.out 100 1000
