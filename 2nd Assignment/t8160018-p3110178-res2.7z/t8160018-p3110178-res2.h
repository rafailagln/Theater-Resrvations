#include <stdio.h>

#define Nseat 10
#define Nseatlow 1
#define Nseathigh 5
#define Pcardsuccess 90
#define Ntel 8
#define Ncash 4
#define Tseathigh 10
#define Tseatlow 5
#define NzoneA 5
#define NzoneB 10
#define NzoneC 10
#define PzoneA 20
#define PzoneB 40
#define PzoneC 40
#define CzoneA 30
#define CzoneB 25
#define CzoneC 20
#define Tcashlow 2
#define Tcashhigh 4
