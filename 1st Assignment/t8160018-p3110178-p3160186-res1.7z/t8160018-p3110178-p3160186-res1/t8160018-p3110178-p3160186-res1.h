#include <stdio.h>

#define Nseat 250
#define Nseatlow 1
#define Nseathigh 5
#define Cseat 20
#define Pcardsuccess 90
#define Ntel 8
#define Tseathigh 10
#define Tseatlow 5