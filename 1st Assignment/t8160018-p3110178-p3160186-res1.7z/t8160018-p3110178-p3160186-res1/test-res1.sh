#!/bin/bash
gcc -Wall t8160018-p3110178-p3160186-res1.c -pthread
./a.out 100 1000